# مهران — من فلاح إلى ملك (Android)

This project wraps the supplied complete HTML game in a native Android WebView.
The original game file is kept intact as `app/src/main/assets/mehran.html`.

## Build
Open this folder in Android Studio and let Gradle sync. Then run the `app` configuration on an Android device/emulator.

For Google Play, build a signed Android App Bundle (AAB) from Android Studio.

## App identity
- Name: مهران — من فلاح إلى ملك
- Package: com.mehran.game
- Version: 1.0.0 (versionCode 1)
- Orientation: portrait

## Important
The supplied HTML contains its own embedded manifest/icons and has no external script/style URLs. The Android wrapper therefore does not alter the game's HTML logic.
