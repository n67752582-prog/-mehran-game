# Mehran currently ships as a WebView wrapper; no custom shrinking rules are required.
